from django.apps import AppConfig


class CreateHikeConfig(AppConfig):
    name = 'CreateHike'
