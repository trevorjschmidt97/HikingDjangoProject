from django.apps import AppConfig


class HikesConfig(AppConfig):
    name = 'Hikes'
