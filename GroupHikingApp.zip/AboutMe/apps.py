from django.apps import AppConfig


class AboutMeConfig(AppConfig):
    name = 'AboutMe'
